from __future__ import annotations

from pathlib import Path
from datetime import datetime
import hashlib, io, json, os, re, warnings

import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle

st.set_page_config(page_title="CustomerIQ | CSV Analytics", page_icon="📊", layout="wide", initial_sidebar_state="expanded")
BASE_DIR = Path(__file__).parent
DATA_PATH = BASE_DIR / "data" / "sample_retail_transactions.csv"
MAX_UPLOAD_MB = 50
ROLE_OPTIONS = ["unknown", "customer_id", "transaction_id", "order_id", "transaction_date", "signup_date", "date_time", "quantity", "unit_price", "revenue", "sales_amount", "product_name", "category", "brand", "region", "country", "age", "income", "gender", "location", "numeric_measure", "categorical", "text", "target"]



def read_csv_bytes(data: bytes) -> pd.DataFrame:
    if not data:
        raise ValueError("The uploaded CSV is empty.")
    if len(data) > MAX_UPLOAD_MB * 1024 * 1024:
        raise ValueError(f"File exceeds the {MAX_UPLOAD_MB} MB upload limit.")
    errors = []
    for encoding in ("utf-8-sig", "utf-8", "cp1252", "latin-1"):
        try:
            df = pd.read_csv(io.BytesIO(data), encoding=encoding, low_memory=False)
            if len(df.columns) == 0:
                raise ValueError("No columns were found in this CSV.")
            return make_unique_columns(df)
        except Exception as exc:
            errors.append(str(exc))
    raise ValueError("Could not parse this CSV. Check its delimiter, quoting, and file contents.")


def make_unique_columns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    seen, cols = {}, []
    for i, c in enumerate(df.columns):
        name = str(c).strip() or f"column_{i+1}"
        count = seen.get(name, 0); seen[name] = count + 1
        cols.append(name if count == 0 else f"{name}.{count+1}")
    df.columns = cols
    return df


def schema_metadata(df: pd.DataFrame) -> dict:
    cols = []
    for c in df.columns:
        s = df[c]
        sample = s.dropna().head(3).tolist()
        safe_samples = []
        for x in sample:
            # Only low-risk shape examples; never send actual string values or identifiers.
            if pd.api.types.is_numeric_dtype(s): safe_samples.append("numeric_value")
            elif pd.api.types.is_datetime64_any_dtype(s): safe_samples.append("date_value")
            else: safe_samples.append(f"text_length_{min(len(str(x)), 50)}")
        cols.append({"name": str(c), "dtype": str(s.dtype), "missing_pct": round(float(s.isna().mean()*100), 2), "unique_count": int(s.nunique(dropna=True)), "safe_examples": list(dict.fromkeys(safe_samples))[:3]})
    return {"rows": int(len(df)), "column_count": len(df.columns), "columns": cols}


def heuristic_schema(df: pd.DataFrame) -> dict:
    mapping, date_cols = {}, []
    patterns = [
        ("customer_id", r"customer.?id|client.?no|client.?id|user.?id|member.?id|account.?id"),
        ("transaction_id", r"transaction.?id|trans.?id"), ("order_id", r"invoice.?no|order.?id|order.?no|receipt.?id"),
        ("transaction_date", r"invoice.?date|order.?date|order.?dt|transaction.?date|purchase.?date|sales.?date"),
        ("signup_date", r"signup.?date|registration.?date|joined.?date"), ("date_time", r"date|time|timestamp|created.?at"),
        ("quantity", r"quantity|qty|units.?sold|units|count"), ("unit_price", r"unit.?price|price.?per.?unit|item.?price|price"),
        ("revenue", r"revenue|sales.?amount|total.?sales|turnover|amount"), ("sales_amount", r"^sales$|total.?amount|monetary|spend"),
        ("product_name", r"product|item.?name|description|sku|stock.?code"), ("category", r"category|department|class|segment"),
        ("brand", r"brand|manufacturer"), ("region", r"region|state|province|territory"), ("country", r"country|nation"),
        ("age", r"^age$|customer.?age"), ("income", r"income|salary|annual.?earnings"), ("gender", r"gender|sex"),
        ("location", r"location|city|address|postal|zip"), ("target", r"target|label|outcome|class|churn|default|diagnosis|^y$"),
    ]
    for c in df.columns:
        norm = re.sub(r"[^a-z0-9]+", "_", str(c).lower()).strip("_")
        role = None
        for candidate, pat in patterns:
            if re.search(pat, norm): role = candidate; break
        s = df[c]
        if role is None and ("date" in norm or "time" in norm): role = "date_time"
        if role is None and pd.api.types.is_numeric_dtype(s): role = "numeric_measure"
        if role is None and (s.nunique(dropna=True) <= max(30, int(len(s)*.15))): role = "categorical"
        if role is None: role = "text"
        mapping[c] = role
    roles = list(mapping.values())
    dtype_family = "retail_transactions" if "customer_id" in roles and "transaction_date" in roles and ("revenue" in roles or "sales_amount" in roles or ("quantity" in roles and "unit_price" in roles)) else "customer_profiles" if "transaction_date" not in roles and any(r in roles for r in ("age", "income", "gender")) else "sales" if any(r in roles for r in ("revenue", "sales_amount")) else "general_structured"
    return {"dataset_type": dtype_family, "columns": mapping, "confidence": 0.55, "missing_roles": [], "warnings": ["Local heuristic detection used."]}


def get_api_key():
    key = os.getenv("GEMINI_API_KEY", "").strip()
    if key: return key
    try: return str(st.secrets.get("GEMINI_API_KEY", "")).strip()
    except Exception: return ""

@st.cache_data(show_spinner=False, ttl=86400)
def _gemini_schema_cached(fingerprint: str, metadata_json: str, model: str, api_key: str) -> dict:
    # API key is an internal cache argument and is never rendered or logged.
    from google import genai
    client = genai.Client(api_key=api_key, http_options={"timeout": 15000})
    prompt = """Classify the semantic role of each CSV column. Return ONLY valid JSON with keys dataset_type, columns, confidence, missing_roles, warnings. dataset_type must be one of retail_transactions, customer_profiles, sales, general_structured. columns must map every exact provided column name to one role from: customer_id, transaction_id, order_id, transaction_date, signup_date, date_time, quantity, unit_price, revenue, sales_amount, product_name, category, brand, region, country, age, income, gender, location, numeric_measure, categorical, text, target, unknown. Use only exact supplied column names. Do not infer facts from rows; no analysis. Values in safe_examples are synthetic shape descriptors, not real data. Keep confidence between 0 and 1. Do not add markdown."""
    response = client.models.generate_content(model=model, contents=prompt + "\nSCHEMA METADATA:\n" + metadata_json, config={"response_mime_type":"application/json", "temperature":0})
    return json.loads(response.text)


def validate_schema(candidate, df):
    if not isinstance(candidate, dict): raise ValueError("Schema response is not an object")
    dataset_type = candidate.get("dataset_type")
    if dataset_type not in {"retail_transactions", "customer_profiles", "sales", "general_structured"}: raise ValueError("Invalid dataset type")
    cols = candidate.get("columns")
    if not isinstance(cols, dict) or set(cols.keys()) != set(map(str, df.columns)): raise ValueError("Column mapping does not exactly match uploaded columns")
    if any(role not in ROLE_OPTIONS for role in cols.values()): raise ValueError("Unknown semantic role returned")
    confidence = float(candidate.get("confidence", 0))
    if not 0 <= confidence <= 1: raise ValueError("Invalid confidence")
    if confidence < 0.35: raise ValueError("Schema confidence is too low to apply safely")
    # Avoid applying an incompatible retail type unless the required semantic fields are present.
    roles = set(cols.values())
    if dataset_type == "retail_transactions" and not ("customer_id" in roles and "transaction_date" in roles and ("revenue" in roles or "sales_amount" in roles or ("quantity" in roles and "unit_price" in roles))):
        raise ValueError("Retail classification is incompatible with mapped columns")
    candidate["confidence"] = confidence
    candidate["missing_roles"] = candidate.get("missing_roles", []) if isinstance(candidate.get("missing_roles", []), list) else []
    candidate["warnings"] = candidate.get("warnings", []) if isinstance(candidate.get("warnings", []), list) else []
    if not all(isinstance(x, str) for x in candidate["missing_roles"] + candidate["warnings"]): raise ValueError("Invalid schema metadata fields")
    return candidate


def detect_schema(df):
    metadata = schema_metadata(df)
    fingerprint = hashlib.sha256(json.dumps(metadata, sort_keys=True).encode()).hexdigest()
    model = os.getenv("GEMINI_MODEL", "gemini-3.1-flash-lite").strip() or "gemini-3.1-flash-lite"
    key = get_api_key()
    if key:
        try:
            result = validate_schema(_gemini_schema_cached(fingerprint, json.dumps(metadata, sort_keys=True), model, key), df)
            return result, f"Gemini ({model})", None
        except Exception as exc:
            # Do not show raw API exceptions; they may contain request metadata.
            fallback_reason = "Gemini request failed or returned an invalid schema; local detection is active."
    else: fallback_reason = "GEMINI_API_KEY is not configured; local detection is active."
    return validate_schema(heuristic_schema(df), df), "Local heuristic fallback", fallback_reason


def role_columns(mapping, role): return [c for c, r in mapping.items() if r == role]
def first_role(mapping, *roles):
    for role in roles:
        found = role_columns(mapping, role)
        if found: return found[0]
    return None

def prepare_analysis(df, mapping):
    data = df.copy()
    date_col = first_role(mapping, "transaction_date", "signup_date", "date_time")
    numeric_cols = [c for c in data.columns if mapping.get(c) in {"quantity", "unit_price", "revenue", "sales_amount", "numeric_measure", "age", "income"}]
    for c in numeric_cols: data[c] = pd.to_numeric(data[c], errors="coerce")
    parsed_date = None
    if date_col:
        parsed = pd.to_datetime(data[date_col], errors="coerce", format="mixed")
        if parsed.notna().sum() >= max(2, int(len(data)*.25)):
            data[date_col] = parsed; parsed_date = date_col
    qty, price = first_role(mapping, "quantity"), first_role(mapping, "unit_price")
    revenue = first_role(mapping, "revenue", "sales_amount")
    if revenue is None and qty and price:
        data["CalculatedRevenue"] = data[qty] * data[price]; revenue = "CalculatedRevenue"
    return data, parsed_date, revenue


def cluster_frame(df, cols, k):
    if len(cols) < 2: raise ValueError("Select at least two numeric features for clustering.")
    x = df[cols].replace([np.inf, -np.inf], np.nan)
    x = x.apply(pd.to_numeric, errors="coerce")
    x = x.fillna(x.median(numeric_only=True)).fillna(0)
    keep = x.nunique(dropna=False) > 1
    x = x.loc[:, keep]
    if x.shape[1] < 2: raise ValueError("At least two non-constant numeric features are required.")
    if len(x) < 3: raise ValueError("At least three rows are required for clustering.")
    k = min(max(2, int(k)), len(x)-1)
    if x.shape[0] > 50000: x = x.sample(50000, random_state=42); source_index = x.index
    else: source_index = x.index
    scaled = StandardScaler().fit_transform(x)
    labels = KMeans(n_clusters=k, random_state=42, n_init=10).fit_predict(scaled)
    score = silhouette_score(scaled, labels, sample_size=min(len(labels), 5000), random_state=42) if len(np.unique(labels)) > 1 and len(labels) > k else np.nan
    result = df.loc[source_index].copy(); result["Cluster"] = labels
    return result, score, list(x.columns)


def create_pdf_report(df, mapping, dataset_type, source_name, quality, summary_lines):
    buffer = io.BytesIO(); doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=15*mm, leftMargin=15*mm, topMargin=15*mm, bottomMargin=15*mm)
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="CIQTitle", parent=styles["Title"], textColor=colors.HexColor("#174b65"), fontSize=22, leading=26, spaceAfter=8))
    styles.add(ParagraphStyle(name="CIQSection", parent=styles["Heading2"], textColor=colors.HexColor("#174b65"), spaceBefore=10, spaceAfter=5))
    story = [Paragraph("CustomerIQ", styles["CIQTitle"]), Paragraph("Dataset Analytics Report", styles["Heading2"]), Paragraph(f"Source: {source_name} · Generated: {datetime.now():%d %b %Y %H:%M}", styles["BodyText"]), Spacer(1, 8), Paragraph("1. Dataset profile", styles["CIQSection"])]
    rows = [["Property", "Value"], ["Dataset type", dataset_type], ["Rows", f"{len(df):,}"], ["Columns", str(len(df.columns))], ["Duplicate rows", f"{int(df.duplicated().sum()):,}"], ["Columns with missing values", str(int(df.isna().any().sum()))]]
    t = Table(rows, colWidths=[55*mm, 115*mm]); t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#174b65")),("TEXTCOLOR",(0,0),(-1,0),colors.white),("GRID",(0,0),(-1,-1),.4,colors.lightgrey),("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white,colors.HexColor("#F3F7F8")]),("PADDING",(0,0),(-1,-1),6)])); story.append(t)
    story.append(Paragraph("2. Data quality", styles["CIQSection"]))
    qrows = [["Check", "Result"]] + [[str(r[0]), str(r[1])] for r in quality]
    qt = Table(qrows, colWidths=[85*mm,85*mm]); qt.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#187f83")),("TEXTCOLOR",(0,0),(-1,0),colors.white),("GRID",(0,0),(-1,-1),.4,colors.lightgrey),("PADDING",(0,0),(-1,-1),5)])); story.append(qt)
    story.append(Paragraph("3. Calculated findings", styles["CIQSection"]))
    for line in summary_lines[:20]: story.append(Paragraph("• " + str(line), styles["BodyText"])); story.append(Spacer(1, 3))
    story.append(Paragraph("4. Detected column roles", styles["CIQSection"]))
    role_rows = [["Column", "Role"]] + [[str(c)[:80], str(mapping.get(c,"unknown"))] for c in df.columns]
    rt = Table(role_rows, colWidths=[100*mm,70*mm], repeatRows=1); rt.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#174b65")),("TEXTCOLOR",(0,0),(-1,0),colors.white),("GRID",(0,0),(-1,-1),.3,colors.lightgrey),("FONTSIZE",(0,0),(-1,-1),8),("PADDING",(0,0),(-1,-1),4)])); story.append(rt)
    story.append(Spacer(1, 8)); story.append(Paragraph("Methodology and limitations: metrics in this report are calculated locally from the provided CSV. Semantic column roles may be heuristic or AI-assisted and should be reviewed when ambiguous. Correlation and clustering indicate patterns, not causation. Analyses are omitted when required data is unavailable.", styles["Italic"]))
    doc.build(story); return buffer.getvalue()



@st.cache_data(show_spinner=False, ttl=3600)
def _gemini_insights_cached(payload_json: str, model: str, api_key: str) -> list:
    from google import genai
    client = genai.Client(api_key=api_key, http_options={"timeout": 20000})
    prompt = """You are a cautious data analyst. Interpret only the supplied aggregate findings; do not invent statistics or causes.
Return ONLY JSON: {"insights":[{"finding":"...","evidence":"...","why_it_matters":"...","action":"...","priority":"Low|Medium|High"}]}.
Provide at most 3 concise items. Every evidence statement must be directly supported by the supplied findings. Treat correlation as association, not causation. If the evidence is weak, return an empty insights list. Do not request or infer raw records."""
    response = client.models.generate_content(
        model=model,
        contents=prompt + "\nAGGREGATE FINDINGS:\n" + payload_json,
        config={"response_mime_type": "application/json", "temperature": 0}
    )
    parsed = json.loads(response.text)
    if not isinstance(parsed, dict) or not isinstance(parsed.get("insights"), list):
        raise ValueError("Invalid insight response")
    safe = []
    for item in parsed["insights"][:3]:
        if not isinstance(item, dict):
            continue
        fields = {k: item.get(k, "") for k in ("finding", "evidence", "why_it_matters", "action", "priority")}
        if not all(isinstance(v, str) for v in fields.values()):
            continue
        if fields["priority"] not in {"Low", "Medium", "High"}:
            fields["priority"] = "Low"
        if not fields["finding"] or not fields["evidence"] or not fields["action"]:
            continue
        safe.append(fields)
    return safe

# Load .env when available; environment variables and Streamlit secrets remain supported.
try:
    from dotenv import load_dotenv
    load_dotenv(BASE_DIR / ".env")
except Exception:
    pass

# Single-page CustomerIQ workspace
st.markdown("""
<style>
.block-container{padding-top:1.25rem;padding-bottom:3rem;max-width:1440px}
.hero{padding:1.35rem 1.55rem;border:1px solid rgba(100,116,139,.22);border-radius:16px;background:linear-gradient(115deg,#10233f,#174b65 58%,#187f83);color:white;margin-bottom:1rem}
.hero h1{margin:0;font-size:2rem;color:white;letter-spacing:-.03em}
.hero p{margin:.4rem 0 0;color:#d8eef2;font-size:1rem}
.section-label{font-size:.78rem;text-transform:uppercase;letter-spacing:.08em;color:#187f83;font-weight:700;margin-bottom:.15rem}
div[data-testid="stMetric"]{border:1px solid rgba(128,145,160,.25);padding:.8rem 1rem;border-radius:12px;background:rgba(128,145,160,.045)}
div[data-testid="stMetricLabel"]{font-size:.85rem}
hr{margin:1.25rem 0}
</style>
<div class="hero"><h1>CustomerIQ</h1><p>Understand your data. Find meaningful patterns. Decide what to do next.</p></div>
""", unsafe_allow_html=True)

with st.sidebar:
    st.header("Your dataset")
    uploaded = st.file_uploader("Upload a CSV file", type=["csv"], help=f"Maximum file size: {MAX_UPLOAD_MB} MB")
    use_sample = st.checkbox("Use bundled retail demo", value=uploaded is None)
    st.divider()
    st.caption("Analysis settings")
    n_clusters = st.slider("Number of clusters", 2, 8, 4)
    st.caption("Gemini AI is optional. Without a key, analysis uses local Python rules.")

try:
    if uploaded is not None:
        raw_df = read_csv_bytes(uploaded.getvalue())
        source_name = uploaded.name
    elif use_sample:
        raw_df = read_csv_bytes(DATA_PATH.read_bytes())
        source_name = "sample_retail_transactions.csv"
    else:
        st.info("Upload a CSV in the sidebar, or enable the bundled retail demo to explore CustomerIQ.")
        st.stop()
except Exception as exc:
    st.error(str(exc))
    st.stop()

if raw_df.empty:
    st.error("This CSV contains headers but no data rows.")
    st.stop()
if len(raw_df.columns) > 500:
    st.error("This dataset has more than 500 columns. Reduce its width to 500 or fewer before analysis.")
    st.stop()

with st.spinner("Understanding your dataset…"):
    schema, detection_source, fallback_message = detect_schema(raw_df)
if fallback_message:
    st.caption(f"AI status: {fallback_message}")
else:
    st.caption(f"AI-assisted schema detection active: {detection_source}")
st.caption(f"**{source_name}** · {len(raw_df):,} rows · {len(raw_df.columns):,} columns · Dataset family: `{schema['dataset_type']}`")

with st.expander("Review and correct column meanings", expanded=False):
    st.write("Change any role that was detected incorrectly. Original column names are preserved.")
    edited = {}
    for i, col in enumerate(raw_df.columns):
        current = schema["columns"].get(col, "unknown")
        options = ROLE_OPTIONS
        edited[col] = st.selectbox(
            str(col), options,
            index=options.index(current) if current in options else 0,
            key=f"role_{i}_{hashlib.md5(str(col).encode()).hexdigest()[:8]}"
        )
    schema["columns"] = edited
    if st.button("Reclassify dataset from these roles", key="apply_roles"):
        st.rerun()

mapping = schema["columns"]
data, date_col, revenue_col = prepare_analysis(raw_df, mapping)
num_cols = data.select_dtypes(include=np.number).columns.tolist()
date_cols = [c for c in data.columns if pd.api.types.is_datetime64_any_dtype(data[c])]
cat_cols = [c for c in data.columns if c not in num_cols and c not in date_cols]
customer_col = first_role(mapping, "customer_id")
order_col = first_role(mapping, "transaction_id", "order_id")
product_col = first_role(mapping, "product_name", "category", "brand")
location_col = first_role(mapping, "country", "region", "location")
missing_count = int(data.isna().sum().sum())
missing_pct = (data.isna().mean() * 100).sort_values(ascending=False)
duplicate_count = int(data.duplicated().sum())
incomplete_rows = int(data.isna().any(axis=1).sum())
constant_cols = [c for c in data.columns if data[c].nunique(dropna=False) <= 1]
quality = [
    ("Missing cells", f"{missing_count:,}"),
    ("Duplicate rows", f"{duplicate_count:,}"),
    ("Rows with missing values", f"{incomplete_rows:,}"),
    ("Constant columns", f"{len(constant_cols):,}")
]
summary_lines = [
    f"Dataset contains {len(data):,} rows and {len(data.columns):,} columns.",
    f"{missing_count:,} missing cells ({missing_count / max(1, data.size) * 100:.2f}% of all cells).",
    f"{duplicate_count:,} duplicate rows.",
    f"{incomplete_rows:,} rows have at least one missing value."
]
if revenue_col:
    total_revenue = pd.to_numeric(data[revenue_col], errors="coerce").sum(min_count=1)
    if pd.notna(total_revenue):
        summary_lines.append(f"Total {revenue_col}: {total_revenue:,.2f}.")
if date_col and data[date_col].notna().any():
    summary_lines.append(f"Date coverage: {data[date_col].min().date()} to {data[date_col].max().date()}.")
if customer_col:
    summary_lines.append(f"Unique customers: {data[customer_col].nunique(dropna=True):,}.")

# Overview metrics: only domain metrics that have supporting fields are shown.
st.markdown('<div class="section-label">Dataset overview</div>', unsafe_allow_html=True)
metric_cols = st.columns(5 if revenue_col and customer_col else 4)
metric_cols[0].metric("Records", f"{len(data):,}")
metric_cols[1].metric("Columns", f"{len(data.columns):,}")
metric_cols[2].metric("Numeric fields", f"{len(num_cols):,}")
metric_cols[3].metric("Missing cells", f"{missing_count:,}", f"{missing_count / max(1, data.size) * 100:.1f}% of all cells")
if revenue_col and customer_col:
    metric_cols[4].metric("Unique customers", f"{data[customer_col].nunique(dropna=True):,}")

with st.expander("Preview the uploaded data", expanded=False):
    st.dataframe(data.head(20), use_container_width=True, hide_index=True)
    st.caption("Preview preserves the original rows. No rows are automatically deleted.")

# Quality overview
st.divider()
st.markdown('<div class="section-label">01 · Data quality</div>', unsafe_allow_html=True)
st.subheader("How complete and consistent is this dataset?")
q1, q2, q3, q4 = st.columns(4)
q1.metric("Missing cells", f"{missing_count:,}")
q2.metric("Duplicate rows", f"{duplicate_count:,}")
q3.metric("Incomplete rows", f"{incomplete_rows:,}")
q4.metric("Constant columns", f"{len(constant_cols):,}")
if missing_pct.max() > 0:
    missing_plot = pd.DataFrame({"Column": missing_pct[missing_pct > 0].head(20).index, "Missing (%)": missing_pct[missing_pct > 0].head(20).values})
    st.plotly_chart(px.bar(missing_plot.sort_values("Missing (%)"), x="Missing (%)", y="Column", orientation="h",
                           title="Which columns have the most missing values?", template="plotly_white",
                           color="Missing (%)", color_continuous_scale=["#8bc6c9", "#c75b5b"]).update_layout(coloraxis_showscale=False),
                    use_container_width=True)
else:
    st.success("No missing values were detected.")
quality_details = []
for c in data.columns:
    s = data[c]
    if s.isna().any():
        quality_details.append({"Finding": "Missing values", "Column": c, "Details": f"{int(s.isna().sum()):,} missing ({s.isna().mean()*100:.1f}%)"})
    if s.nunique(dropna=False) <= 1:
        quality_details.append({"Finding": "Constant column", "Column": c, "Details": "Only one distinct value including missing values"})
if quality_details:
    st.dataframe(pd.DataFrame(quality_details), use_container_width=True, hide_index=True)
if date_col:
    invalid_dates = int(raw_df[date_col].notna().sum() - data[date_col].notna().sum())
    st.caption(f"Date parsing: {int(data[date_col].notna().sum()):,} valid values; {max(0, invalid_dates):,} non-empty values could not be parsed.")
outlier_rows = []
for c in num_cols[:40]:
    s = data[c].replace([np.inf, -np.inf], np.nan).dropna()
    if len(s) >= 4 and s.nunique() > 1:
        q25, q75 = s.quantile([.25, .75])
        iqr = q75 - q25
        if iqr > 0:
            count = int(((s < q25 - 1.5 * iqr) | (s > q75 + 1.5 * iqr)).sum())
            if count:
                outlier_rows.append({"Column": c, "Potential outliers (IQR rule)": count, "Share of valid values (%)": round(count / len(s) * 100, 2)})
if outlier_rows:
    with st.expander("Potential numerical outliers (IQR rule)"):
        st.caption("These are candidates for review, not confirmed errors. No values are removed.")
        st.dataframe(pd.DataFrame(outlier_rows).sort_values("Potential outliers (IQR rule)", ascending=False), use_container_width=True, hide_index=True)

# Visual analytics
st.divider()
st.markdown('<div class="section-label">02 · Explore patterns</div>', unsafe_allow_html=True)
st.subheader("What stands out in the data?")
if not num_cols and not cat_cols:
    st.info("No usable columns were found for charting.")
else:
    left, right = st.columns(2)
    with left:
        if num_cols:
            dist_col = st.selectbox("Explore a numerical distribution", num_cols, key="dist_col")
            s = data[dist_col].replace([np.inf, -np.inf], np.nan).dropna()
            if len(s):
                fig = px.histogram(s.to_frame(), x=dist_col, nbins=35, marginal="box",
                                   title=f"How is {dist_col} distributed?", template="plotly_white",
                                   color_discrete_sequence=["#187f83"])
                fig.update_layout(xaxis_title=dist_col, yaxis_title="Records", bargap=.08)
                st.plotly_chart(fig, use_container_width=True)
                if len(s) >= 2:
                    st.caption(f"Median: {s.median():,.3g} · Mean: {s.mean():,.3g} · Valid values: {len(s):,}.")
        elif cat_cols:
            cat = st.selectbox("Explore category frequency", cat_cols, key="dist_cat_left")
            counts = data[cat].fillna("(Missing)").astype(str).value_counts().head(15).rename_axis(cat).reset_index(name="Records")
            st.plotly_chart(px.bar(counts.sort_values("Records"), x="Records", y=cat, orientation="h",
                                   title=f"Which {cat} values occur most often?", template="plotly_white"), use_container_width=True)
    with right:
        if cat_cols:
            cat_col = st.selectbox("Most common categories", cat_cols, key="top_cat")
            counts = data[cat_col].fillna("(Missing)").astype(str).value_counts().head(12).rename_axis(cat_col).reset_index(name="Records")
            fig = px.bar(counts.sort_values("Records"), x="Records", y=cat_col, orientation="h",
                         title=f"Which {cat_col} values are most frequent?", template="plotly_white",
                         color="Records", color_continuous_scale=["#a8d9d6", "#174b65"])
            fig.update_layout(coloraxis_showscale=False)
            st.plotly_chart(fig, use_container_width=True)
            if len(counts):
                st.caption(f"Most frequent value: {counts.sort_values('Records', ascending=False).iloc[0][cat_col]} ({int(counts['Records'].max()):,} records).")
        elif num_cols:
            st.write("Add categorical columns to compare groups.")

    if len(num_cols) >= 2:
        st.markdown("#### Which numerical fields move together?")
        corr_cols = num_cols[:20]
        corr = data[corr_cols].corr(numeric_only=True)
        fig = px.imshow(corr, text_auto=".2f", aspect="auto", color_continuous_scale="RdBu_r", zmin=-1, zmax=1,
                        title="Correlation between numerical fields", template="plotly_white")
        st.plotly_chart(fig, use_container_width=True)
        st.caption("Correlation describes linear association; it does not establish cause and effect.")

    if cat_cols and num_cols:
        st.markdown("#### How does a measure differ across groups?")
        compare_left, compare_right = st.columns(2)
        with compare_left:
            compare_cat = st.selectbox("Group by", cat_cols, key="group_compare")
        with compare_right:
            compare_metric = st.selectbox("Measure", num_cols, key="metric_compare")
        agg_choice = st.selectbox("Aggregation", ["Mean", "Median", "Sum", "Record count"], key="aggregation")
        grouped_data = data[[compare_cat, compare_metric]].copy()
        grouped_data[compare_cat] = grouped_data[compare_cat].fillna("(Missing)").astype(str)
        grouped_data = grouped_data.groupby(compare_cat)[compare_metric]
        if agg_choice == "Mean":
            grouped = grouped_data.agg(["mean", "count"]).reset_index().rename(columns={"mean": "Value", "count": "Sample size"})
        elif agg_choice == "Median":
            grouped = grouped_data.agg(["median", "count"]).reset_index().rename(columns={"median": "Value", "count": "Sample size"})
        elif agg_choice == "Sum":
            grouped = grouped_data.agg(["sum", "count"]).reset_index().rename(columns={"sum": "Value", "count": "Sample size"})
        else:
            grouped = grouped_data.size().reset_index(name="Value").rename(columns={"size": "Value"})
            grouped["Sample size"] = grouped["Value"]
        grouped = grouped.sort_values("Value", ascending=False).head(25)
        st.plotly_chart(px.bar(grouped.sort_values("Value"), x="Value", y=compare_cat, orientation="h",
                               title=f"{agg_choice} {compare_metric} by {compare_cat}", hover_data=["Sample size"] if "Sample size" in grouped else None,
                               template="plotly_white"), use_container_width=True)
        st.dataframe(grouped, use_container_width=True, hide_index=True)

# Date analysis only when a date field parses successfully.
if date_col and data[date_col].notna().sum() >= 2:
    st.divider()
    st.markdown('<div class="section-label">03 · Time trends</div>', unsafe_allow_html=True)
    st.subheader("How does the dataset change over time?")
    date_valid = data.dropna(subset=[date_col]).copy()
    date_valid["_period"] = date_valid[date_col].dt.to_period("M").dt.to_timestamp()
    if revenue_col:
        time_agg = date_valid.groupby("_period")[revenue_col].sum(min_count=1).reset_index()
        y_axis = revenue_col
        title = f"Monthly {revenue_col}"
    elif num_cols:
        measure = st.selectbox("Numerical measure over time", num_cols, key="time_measure")
        time_agg = date_valid.groupby("_period")[measure].mean().reset_index()
        y_axis = measure
        title = f"Monthly average {measure}"
    else:
        time_agg = date_valid.groupby("_period").size().reset_index(name="Records")
        y_axis = "Records"
        title = "Records by month"
    time_agg.columns = ["Month", y_axis]
    if len(time_agg):
        st.plotly_chart(px.line(time_agg, x="Month", y=y_axis, markers=True, title=title,
                                template="plotly_white", color_discrete_sequence=["#187f83"]), use_container_width=True)
        st.caption(f"Monthly aggregation across {time_agg['Month'].min().date()} to {time_agg['Month'].max().date()}; this describes the observed period only.")
        if len(time_agg) >= 2:
            first_val, last_val = time_agg[y_axis].iloc[0], time_agg[y_axis].iloc[-1]
            if pd.notna(first_val) and pd.notna(last_val) and first_val != 0:
                change = (last_val - first_val) / abs(first_val) * 100
                st.caption(f"First observed month to last observed month: {change:+.1f}% (not a full seasonal or causal analysis).")

# Retail/customer-specific analytics only when relevant roles exist.
can_rfm = bool(customer_col and date_col and order_col and revenue_col)
if revenue_col or customer_col:
    st.divider()
    st.markdown('<div class="section-label">04 · Business analysis</div>', unsafe_allow_html=True)
    st.subheader("Business and customer performance")
    if revenue_col:
        total = pd.to_numeric(data[revenue_col], errors="coerce").sum(min_count=1)
        a, b = st.columns(2)
        a.metric(f"Total {revenue_col}", f"{total:,.2f}" if pd.notna(total) else "—")
        if order_col:
            b.metric("Unique orders", f"{data[order_col].nunique(dropna=True):,}")
        elif customer_col:
            b.metric("Unique customers", f"{data[customer_col].nunique(dropna=True):,}")
        if product_col:
            top_product = data.groupby(product_col, dropna=False)[revenue_col].sum(min_count=1).sort_values(ascending=False).head(15).reset_index()
            st.plotly_chart(px.bar(top_product.sort_values(revenue_col), x=revenue_col, y=product_col, orientation="h",
                                   title=f"Which {product_col} contributes most to {revenue_col}?", template="plotly_white"), use_container_width=True)
        if location_col:
            by_location = data.groupby(location_col, dropna=False)[revenue_col].sum(min_count=1).sort_values(ascending=False).head(15).reset_index()
            st.plotly_chart(px.bar(by_location.sort_values(revenue_col), x=revenue_col, y=location_col, orientation="h",
                                   title=f"{revenue_col} by {location_col}", template="plotly_white"), use_container_width=True)
    if can_rfm:
        st.markdown("#### RFM customer analysis")
        tx = data.dropna(subset=[customer_col, date_col, revenue_col]).copy()
        rfm = tx.groupby(customer_col, dropna=True).agg(
            LastPurchase=(date_col, "max"),
            Frequency=(order_col, "nunique"),
            Monetary=(revenue_col, "sum")
        ).reset_index()
        if len(rfm):
            snapshot = tx[date_col].max().normalize() + pd.Timedelta(days=1)
            rfm["RecencyDays"] = (snapshot - rfm["LastPurchase"].dt.normalize()).dt.days
            rfm["AverageOrderValue"] = rfm["Monetary"] / rfm["Frequency"].replace(0, np.nan)
            rc1, rc2, rc3 = st.columns(3)
            rc1.metric("Customers", f"{len(rfm):,}")
            rc2.metric("Median recency", f"{rfm['RecencyDays'].median():.0f} days")
            rc3.metric("Median customer spend", f"{rfm['Monetary'].median():,.2f}")
            st.plotly_chart(px.scatter(rfm, x="Frequency", y="Monetary", color="RecencyDays",
                                       hover_data=[customer_col], title="Customer frequency vs. monetary value",
                                       color_continuous_scale="Teal", template="plotly_white"), use_container_width=True)
            st.dataframe(rfm.sort_values("Monetary", ascending=False).head(100), use_container_width=True, hide_index=True)
            st.download_button("Download customer RFM table", rfm.to_csv(index=False).encode("utf-8"),
                               "customeriq_rfm.csv", "text/csv")
    elif customer_col:
        st.info("Customer IDs are present, but RFM requires a valid transaction date, order/transaction ID, and monetary measure. Customer-profile counts remain available above.")

# Actionable insights, grounded in locally calculated evidence.
st.divider()
st.markdown('<div class="section-label">05 · Recommendations</div>', unsafe_allow_html=True)
st.subheader("Insights & What to Do Next")
insights = []
if missing_pct.max() > 20:
    col = str(missing_pct.idxmax())
    pct = float(missing_pct.max())
    insights.append(("High", f"Review missing data in {col}", f"{pct:.1f}% of values in this column are missing.",
                     "Check how this field is collected and whether the missingness is expected before using it in analysis."))
if duplicate_count:
    insights.append(("Medium", "Review duplicate records", f"{duplicate_count:,} exact duplicate rows were detected.",
                     "Check whether these rows are accidental duplicates or legitimate repeated observations before removing anything."))
if num_cols:
    candidates = []
    for c in num_cols[:40]:
        s = data[c].replace([np.inf, -np.inf], np.nan).dropna()
        if len(s) >= 5 and s.nunique() > 1:
            candidates.append((c, float(s.mean()), float(s.median()), len(s)))
    skewed = [(c, mean, med, n) for c, mean, med, n in candidates if med != 0 and abs(mean / med) >= 1.5]
    if skewed:
        c, mean, med, n = sorted(skewed, key=lambda x: abs(x[1] / x[2]), reverse=True)[0]
        insights.append(("Low", f"Inspect the distribution of {c}", f"Mean {mean:,.3g}; median {med:,.3g}; {n:,} valid values.",
                         "The mean and median differ substantially. Review the histogram and potential outliers before choosing a summary metric."))
if date_col and data[date_col].notna().sum() >= 2:
    dated = data.dropna(subset=[date_col]).copy()
    dated["_month"] = dated[date_col].dt.to_period("M")
    counts = dated.groupby("_month").size()
    if len(counts) >= 2 and counts.iloc[0] > 0:
        change = (counts.iloc[-1] - counts.iloc[0]) / counts.iloc[0] * 100
        insights.append(("Medium", "Compare activity across observed months",
                         f"Record count changed {change:+.1f}% from the first to the last observed month ({int(counts.iloc[0]):,} to {int(counts.iloc[-1]):,} records).",
                         "Investigate whether the difference reflects genuine activity, partial periods, data collection changes, or missing records."))
if revenue_col and product_col:
    totals = data.groupby(product_col, dropna=False)[revenue_col].sum(min_count=1).dropna().sort_values(ascending=False)
    grand = totals.sum()
    if len(totals) >= 2 and grand > 0:
        share = float(totals.iloc[0] / grand * 100)
        insights.append(("Medium" if share >= 50 else "Low", f"Review concentration in {product_col}",
                         f"The leading category, {str(totals.index[0])[:80]}, represents {share:.1f}% of the summed {revenue_col} across categories.",
                         "Validate the grouping and consider whether dependence on the leading category is acceptable."))
if len(num_cols) >= 2 and len(data) >= 5:
    corr = data[num_cols[:20]].corr(numeric_only=True)
    pairs = []
    for i in range(len(corr.columns)):
        for j in range(i + 1, len(corr.columns)):
            val = corr.iloc[i, j]
            if pd.notna(val):
                pairs.append((abs(float(val)), float(val), corr.columns[i], corr.columns[j]))
    if pairs:
        strength, val, c1, c2 = max(pairs)
        if strength >= .7:
            insights.append(("Low", "Investigate a strong numerical association",
                             f"{c1} and {c2} have a Pearson correlation of {val:.2f} in the available records.",
                             "Check the relationship with a scatter plot and subject-matter context. Correlation does not establish causation."))
if not insights:
    st.info("There is not enough evidence for a strong automatic recommendation. Review the charts and column-role mapping to guide further analysis.")
else:
    for priority, finding, evidence, action in insights:
        with st.container(border=True):
            st.markdown(f"**{finding}**")
            st.caption(f"Priority: {priority}")
            st.write(f"**Evidence:** {evidence}")
            st.write(f"**Why it matters / next step:** {action}")
st.caption("Recommendations are generated from calculated dataset statistics. They identify investigation opportunities, not proven causes.")

# Gemini receives only calculated aggregates and the already-generated local findings, never raw rows.
if get_api_key() and insights:
    with st.expander("Optional Gemini interpretation of these findings"):
        if st.button("Generate AI interpretation", key="gemini_interpret"):
            try:
                model_name = os.getenv("GEMINI_MODEL", "gemini-2.5-flash").strip() or "gemini-2.5-flash"
                aggregate_payload = {
                    "dataset_shape": {"rows": int(len(data)), "columns": int(len(data.columns))},
                    "quality": {"missing_cells": missing_count, "duplicate_rows": duplicate_count,
                                "incomplete_rows": incomplete_rows},
                    "calculated_findings": [
                        {"priority": p, "finding": f, "evidence": e, "recommended_action": a}
                        for p, f, e, a in insights
                    ]
                }
                ai_items = _gemini_insights_cached(
                    json.dumps(aggregate_payload, ensure_ascii=False, sort_keys=True),
                    model_name, get_api_key()
                )
                if not ai_items:
                    st.info("Gemini did not find an additional evidence-supported interpretation.")
                for item in ai_items:
                    st.markdown(f"**{item['finding']}** · {item['priority']} priority")
                    st.write(f"**Evidence:** {item['evidence']}")
                    st.write(f"**Why it matters:** {item['why_it_matters']}")
                    st.write(f"**Suggested action:** {item['action']}")
            except Exception:
                st.warning("Gemini could not complete this request (for example, the model may be unavailable or quota may be exhausted). Local findings remain available.")


# Optional clustering is deliberately secondary and user-triggered.
st.divider()
st.markdown('<div class="section-label">06 · Optional machine learning</div>', unsafe_allow_html=True)
with st.expander("Explore K-Means clusters"):
    st.write("Use clustering to explore groups in numerical features. It is exploratory and does not predict outcomes.")
    eligible_num = [c for c in num_cols if data[c].nunique(dropna=True) > 1]
    selected_features = st.multiselect("Select at least two numerical features", eligible_num,
                                       default=eligible_num[:min(3, len(eligible_num))], key="cluster_features")
    if st.button("Run K-Means clustering", key="run_clusters"):
        try:
            clustered, score, used_features = cluster_frame(data, selected_features, n_clusters)
            st.success(f"Clustered {len(clustered):,} rows using {', '.join(used_features)}.")
            if np.isfinite(score):
                st.metric("Silhouette score", f"{score:.3f}")
            else:
                st.caption("Silhouette score is not meaningful for this result.")
            st.caption("Cluster labels are algorithmic groups, not ground-truth classes. Data may be sampled for large datasets.")
            st.dataframe(clustered.head(1000), use_container_width=True, hide_index=True)
            if len(used_features) >= 2:
                plot_cluster = clustered[used_features[:2] + ["Cluster"]].copy()
                st.plotly_chart(px.scatter(plot_cluster, x=used_features[0], y=used_features[1], color="Cluster",
                                           title="K-Means groups across the first two selected features",
                                           template="plotly_white"), use_container_width=True)
            st.download_button("Download clustered dataset", clustered.to_csv(index=False).encode("utf-8"),
                               "customeriq_clustered.csv", "text/csv")
        except Exception as exc:
            st.warning(str(exc))

# Exports
st.divider()
st.markdown('<div class="section-label">07 · Export</div>', unsafe_allow_html=True)
st.subheader("Take your analysis with you")
export_left, export_right = st.columns(2)
with export_left:
    st.download_button("Download analyzed dataset (CSV)", data.to_csv(index=False).encode("utf-8"),
                       "customeriq_dataset.csv", "text/csv", use_container_width=True)
    roles_df = pd.DataFrame({"Column": list(mapping.keys()), "Role": [mapping[c] for c in mapping],
                             "Data type": [str(data[c].dtype) for c in mapping]})
    st.download_button("Download column-role mapping", roles_df.to_csv(index=False).encode("utf-8"),
                       "customeriq_column_roles.csv", "text/csv", use_container_width=True)
with export_right:
    try:
        pdf_bytes = create_pdf_report(data, mapping, schema["dataset_type"], source_name, quality, summary_lines)
        st.download_button("Download PDF analytics report", pdf_bytes, "CustomerIQ_Analytics_Report.pdf",
                           "application/pdf", use_container_width=True)
    except Exception as exc:
        st.warning(f"PDF report could not be generated: {type(exc).__name__}. CSV exports remain available.")
    st.caption("The PDF includes dataset profile, quality checks, calculated findings, column roles, and methodology notes.")

st.caption("CustomerIQ · Single-page dynamic CSV analytics · Calculations and visualizations run locally in Python.")
